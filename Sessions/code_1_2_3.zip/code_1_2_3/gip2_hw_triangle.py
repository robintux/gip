def triangle_printout(w):
    for i in range(w, 0, -1):
        print '*' * i
