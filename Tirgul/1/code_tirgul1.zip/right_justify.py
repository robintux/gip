s = input("Give me a string: ")
print(" " * (70 - len(s)) + s)
